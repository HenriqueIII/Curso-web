const calculaSalario = (horas, valor) => {
    return `Salario igual a ${horas*valor}€`
}

console.log(calculaSalario(150, 40.5))