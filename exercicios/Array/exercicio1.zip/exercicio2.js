const converte = ano => {
    console.log(`${ano*365} dias`)
}

converte(25)
converte(70)