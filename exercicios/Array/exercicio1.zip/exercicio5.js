const maiorOuIgual = (a, b) => {
    // if(a >= b){
    //     return true
    // }else
    //     return false
    return a >= b
}

console.log(maiorOuIgual(0, 0))
console.log(maiorOuIgual(0, "0"))
console.log(maiorOuIgual(5, 1))
console.log(maiorOuIgual(1, 5))
console.log(maiorOuIgual(0, "1"))
